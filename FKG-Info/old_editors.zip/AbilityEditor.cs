﻿using System;
using System.Windows.Forms;

namespace FKG_Info
{
    public partial class AbilityEditor : Form
    {
        FlowerInfo Flower;

        ToolTip TTip;

        public AbilityEditor(FlowerInfo flower)
        {
            InitializeComponent();

            string TTipText = "AllyNum*DmgMul" + Environment.NewLine + "AllyNum*DefMul" + Environment.NewLine + "EnmNum*AtkMul" + Environment.NewLine + "CnAtk*Chance/10";

            TTip = new ToolTip();
            TTip.SetToolTip(NumBPow01, TTipText);
            TTip.SetToolTip(NumBPow02, TTipText);
            TTip.SetToolTip(NumRPow01, TTipText);
            TTip.SetToolTip(NumRPow02, TTipText);

            Flower = flower;

            /*
            foreach (AbilityInfo.Special FlowerInfo.AbilityType Type in Enum.GetValues(typeof(FlowerInfo.AbilityType)))
            {
                AECmBoxType01.Items.Add(Type);
                AECmBoxType02.Items.Add(Type);
            }
            */

            
            foreach (AbilityInfo.Special Spec in Enum.GetValues(typeof(AbilityInfo.Special)))
            {
                LsBoxType01.Items.Add(Spec);
                LsBoxType02.Items.Add(Spec);
            }


            //TxBoxFullInfo01.Text = Flower.Ability1.GetInfo();
            //NumBPow01.Value = Flower.Ability1.GetBasePower();
            //NumRPow01.Value = Flower.Ability1.GetRaidPower();
            //Flower.Ability1.SelectInListbox(LsBoxType01);
            
            //TxBoxFullInfo02.Text = Flower.Ability2.GetInfo();
            //NumBPow02.Value = Flower.Ability2.GetBasePower();
            //NumRPow02.Value = Flower.Ability2.GetRaidPower();
            //Flower.Ability2.SelectInListbox(LsBoxType02);
        }

        private void BtCancel_Click(object sender, EventArgs ev)
        {
            this.Close();
        }

        private void BtOk_Click(object sender, EventArgs ev)
        {
            /*
            string Sp;

            Sp = "";
            foreach(object item in AELsBoxType01.SelectedItems)
            {

            }
            */
            //Program.GetSelectedItemsText(AELsBoxType01);


            //Flower.Ability1.Set(TxBoxFullInfo01.Text, (int)NumBPow01.Value, (int)NumRPow01.Value, GetSelectedItemsText(LsBoxType01));
            //Flower.Ability2.Set(TxBoxFullInfo02.Text, (int)NumBPow02.Value, (int)NumRPow02.Value, GetSelectedItemsText(LsBoxType02));
            
            this.Close();
        }

        private void LsBoxType01_MouseClick(object sender, MouseEventArgs ev)
        {
            if (LsBoxType01.IndexFromPoint(ev.Location) == 0)
            {
                for (int i = 1; i < LsBoxType01.Items.Count; i++) LsBoxType01.SetSelected(i, false);
            }
            else
            {
                LsBoxType01.SetSelected(0, false);
            }
        }

        private void LsBoxType02_MouseClick(object sender, MouseEventArgs ev)
        {
            if (LsBoxType02.IndexFromPoint(ev.Location) == 0)
            {
                for (int i = 1; i < LsBoxType02.Items.Count; i++) LsBoxType02.SetSelected(i, false);
            }
            else
            {
                LsBoxType02.SetSelected(0, false);
            }

        }

        string GetSelectedItemsText(ListBox lb, char sep = ' ')
        {
            string Res = "";

            foreach (object item in lb.SelectedItems)
            {
                Res += item.ToString() + sep;
            }

            return Res.Remove(Res.Length - 1);
        }



        private void GenerateTemplates(int id)
        {
            ListBox.SelectedObjectCollection list;

            if (id == 0)
                list = LsBoxType01.SelectedItems;
            else
                list = LsBoxType02.SelectedItems;

            AbilityInfo.Special spec;

            string template = "";

            foreach (object item in list)
            {
                try
                {
                    spec = (AbilityInfo.Special)Enum.Parse(typeof(AbilityInfo.Special), item.ToString());
                }
                catch
                {
                    continue;
                }


                switch (spec)
                {
                    case AbilityInfo.Special.AttackUp:
                        template += "Increases the Attack of X party members, including herself, by XX%. ";
                        template += "Increases the Attack of party members by XX%. ";
                        break;
                    case AbilityInfo.Special.DefenceUp:
                        template += "Increases the Defense of party members by XX%. ";
                        break;
                    case AbilityInfo.Special.GuardUp:
                        template += "Increases the characters' guard rate by XX%. ";
                        break;
                    case AbilityInfo.Special.CritRateUp: break;
                    case AbilityInfo.Special.SpeedUp: break;
                    case AbilityInfo.Special.SpeedImmune:
                        template += "Ignore effects from Speed-altering panels in maps. ";
                        break;
                    case AbilityInfo.Special.SkillRatioUp:
                        template += "Increases skill trigger chance up to 20%. ";
                        break;
                    case AbilityInfo.Special.SkillRatioDown: break;
                    case AbilityInfo.Special.SkillDamage:
                        template += "Increases the skill damage of party members by XX%. ";
                        break;
                    case AbilityInfo.Special.Dodge: break;
                    case AbilityInfo.Special.Counterattack:
                        template += "Counterattack with XX% her defensive power at a rate of XX%. ";
                        break;
                    case AbilityInfo.Special.NestHeal:
                        template += "Party members restore XX% HP when passing through bug nest panel. ";
                        break;
                    case AbilityInfo.Special.SolarBlastUp:
                        template += "Increases Solar Drive's effectiveness by XX%. ";
                        break;
                    case AbilityInfo.Special.ShineCrystalDrop: break;
                    case AbilityInfo.Special.LightGaugeFill:
                        template += "Start the subjugation with the Light Gauge XX% filled. ";
                        break;
                    case AbilityInfo.Special.CannonBurst: break;
                    case AbilityInfo.Special.AttackDown: break;
                    case AbilityInfo.Special.DefenceDown: break;
                    case AbilityInfo.Special.HealNodesUp: break;
                    case AbilityInfo.Special.HealNodesEff: break;
                    case AbilityInfo.Special.SmallPestsDef: break;

                    default: break;
                }
            }






            if (id == 0)
                TxBoxFullInfo01.Text = template;
            else
                TxBoxFullInfo02.Text = template;
        }


        private void BtGenerate01_Click(object sender, EventArgs ev)
        {
            GenerateTemplates(0);
        }

        private void BtGenerate02_Click(object sender, EventArgs ev)
        {
            GenerateTemplates(1);
        }
    }
}
