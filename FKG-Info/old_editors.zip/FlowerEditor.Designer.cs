﻿namespace FKG_Info
{
    partial class FlowerEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtOk = new System.Windows.Forms.Button();
            this.PicBoxMain = new System.Windows.Forms.PictureBox();
            this.CmBoxAttackType = new System.Windows.Forms.ComboBox();
            this.TxBoxInfo01 = new System.Windows.Forms.TextBox();
            this.BtSelectBase = new System.Windows.Forms.Button();
            this.BtSelectAwakened = new System.Windows.Forms.Button();
            this.BtSelectBloom = new System.Windows.Forms.Button();
            this.PicBoxIcon = new System.Windows.Forms.PictureBox();
            this.TxBoxKName = new System.Windows.Forms.TextBox();
            this.TxBoxRName = new System.Windows.Forms.TextBox();
            this.TxBoxENutName = new System.Windows.Forms.TextBox();
            this.CmBoxNation = new System.Windows.Forms.ComboBox();
            this.NumRarity = new System.Windows.Forms.NumericUpDown();
            this.TxBoxInfo00 = new System.Windows.Forms.TextBox();
            this.BtCancel = new System.Windows.Forms.Button();
            this.BtAbilities = new System.Windows.Forms.Button();
            this.TxBoxEDMMName = new System.Windows.Forms.TextBox();
            this.BtStats = new System.Windows.Forms.Button();
            this.NumID_Base = new System.Windows.Forms.NumericUpDown();
            this.NumID_Awaken = new System.Windows.Forms.NumericUpDown();
            this.NumID_Bloom = new System.Windows.Forms.NumericUpDown();
            this.BtSkill = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumRarity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumID_Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumID_Awaken)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumID_Bloom)).BeginInit();
            this.SuspendLayout();
            // 
            // BtOk
            // 
            this.BtOk.Location = new System.Drawing.Point(712, 558);
            this.BtOk.Name = "BtOk";
            this.BtOk.Size = new System.Drawing.Size(100, 32);
            this.BtOk.TabIndex = 0;
            this.BtOk.Text = "OK";
            this.BtOk.UseVisualStyleBackColor = true;
            this.BtOk.Click += new System.EventHandler(this.BtOk_Click);
            // 
            // PicBoxMain
            // 
            this.PicBoxMain.Location = new System.Drawing.Point(0, 0);
            this.PicBoxMain.Name = "PicBoxMain";
            this.PicBoxMain.Size = new System.Drawing.Size(602, 602);
            this.PicBoxMain.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PicBoxMain.TabIndex = 1;
            this.PicBoxMain.TabStop = false;
            // 
            // CmBoxAttackType
            // 
            this.CmBoxAttackType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmBoxAttackType.FormattingEnabled = true;
            this.CmBoxAttackType.Location = new System.Drawing.Point(608, 12);
            this.CmBoxAttackType.Name = "CmBoxAttackType";
            this.CmBoxAttackType.Size = new System.Drawing.Size(204, 21);
            this.CmBoxAttackType.TabIndex = 1;
            // 
            // TxBoxInfo01
            // 
            this.TxBoxInfo01.Location = new System.Drawing.Point(714, 161);
            this.TxBoxInfo01.Multiline = true;
            this.TxBoxInfo01.Name = "TxBoxInfo01";
            this.TxBoxInfo01.ReadOnly = true;
            this.TxBoxInfo01.Size = new System.Drawing.Size(98, 100);
            this.TxBoxInfo01.TabIndex = 50;
            this.TxBoxInfo01.TabStop = false;
            this.TxBoxInfo01.Text = "Names:\r\n\r\nKanji\r\nRomaji\r\nEnglish Nutaku\r\nEnglish DMM";
            // 
            // BtSelectBase
            // 
            this.BtSelectBase.Location = new System.Drawing.Point(608, 93);
            this.BtSelectBase.Name = "BtSelectBase";
            this.BtSelectBase.Size = new System.Drawing.Size(64, 32);
            this.BtSelectBase.TabIndex = 4;
            this.BtSelectBase.Text = "Base";
            this.BtSelectBase.UseVisualStyleBackColor = true;
            this.BtSelectBase.Click += new System.EventHandler(this.BtSelectBase_Click);
            // 
            // BtSelectAwakened
            // 
            this.BtSelectAwakened.Location = new System.Drawing.Point(678, 93);
            this.BtSelectAwakened.Name = "BtSelectAwakened";
            this.BtSelectAwakened.Size = new System.Drawing.Size(64, 32);
            this.BtSelectAwakened.TabIndex = 5;
            this.BtSelectAwakened.Text = "Awaken";
            this.BtSelectAwakened.UseVisualStyleBackColor = true;
            this.BtSelectAwakened.Click += new System.EventHandler(this.BtSelectAwakened_Click);
            // 
            // BtSelectBloom
            // 
            this.BtSelectBloom.Location = new System.Drawing.Point(748, 93);
            this.BtSelectBloom.Name = "BtSelectBloom";
            this.BtSelectBloom.Size = new System.Drawing.Size(64, 32);
            this.BtSelectBloom.TabIndex = 6;
            this.BtSelectBloom.Text = "Bloom";
            this.BtSelectBloom.UseVisualStyleBackColor = true;
            this.BtSelectBloom.Click += new System.EventHandler(this.BtSelectBloomed_Click);
            // 
            // PicBoxIcon
            // 
            this.PicBoxIcon.Location = new System.Drawing.Point(608, 161);
            this.PicBoxIcon.Name = "PicBoxIcon";
            this.PicBoxIcon.Size = new System.Drawing.Size(100, 100);
            this.PicBoxIcon.TabIndex = 14;
            this.PicBoxIcon.TabStop = false;
            // 
            // TxBoxKName
            // 
            this.TxBoxKName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxKName.Location = new System.Drawing.Point(608, 267);
            this.TxBoxKName.Name = "TxBoxKName";
            this.TxBoxKName.Size = new System.Drawing.Size(204, 22);
            this.TxBoxKName.TabIndex = 8;
            this.TxBoxKName.TextChanged += new System.EventHandler(this.TxBoxKName_TextChanged);
            // 
            // TxBoxRName
            // 
            this.TxBoxRName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxRName.Location = new System.Drawing.Point(608, 295);
            this.TxBoxRName.Name = "TxBoxRName";
            this.TxBoxRName.ReadOnly = true;
            this.TxBoxRName.Size = new System.Drawing.Size(204, 22);
            this.TxBoxRName.TabIndex = 9;
            // 
            // TxBoxENutName
            // 
            this.TxBoxENutName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxENutName.Location = new System.Drawing.Point(608, 323);
            this.TxBoxENutName.Name = "TxBoxENutName";
            this.TxBoxENutName.Size = new System.Drawing.Size(204, 22);
            this.TxBoxENutName.TabIndex = 10;
            // 
            // CmBoxNation
            // 
            this.CmBoxNation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmBoxNation.FormattingEnabled = true;
            this.CmBoxNation.Location = new System.Drawing.Point(608, 39);
            this.CmBoxNation.Name = "CmBoxNation";
            this.CmBoxNation.Size = new System.Drawing.Size(204, 21);
            this.CmBoxNation.TabIndex = 2;
            // 
            // NumRarity
            // 
            this.NumRarity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumRarity.Location = new System.Drawing.Point(650, 66);
            this.NumRarity.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.NumRarity.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.NumRarity.Name = "NumRarity";
            this.NumRarity.Size = new System.Drawing.Size(36, 21);
            this.NumRarity.TabIndex = 52;
            this.NumRarity.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // TxBoxInfo00
            // 
            this.TxBoxInfo00.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxBoxInfo00.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxBoxInfo00.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxInfo00.Location = new System.Drawing.Point(608, 68);
            this.TxBoxInfo00.Multiline = true;
            this.TxBoxInfo00.Name = "TxBoxInfo00";
            this.TxBoxInfo00.ReadOnly = true;
            this.TxBoxInfo00.Size = new System.Drawing.Size(36, 19);
            this.TxBoxInfo00.TabIndex = 53;
            this.TxBoxInfo00.TabStop = false;
            this.TxBoxInfo00.Text = "Rarity:";
            // 
            // BtCancel
            // 
            this.BtCancel.Location = new System.Drawing.Point(608, 558);
            this.BtCancel.Name = "BtCancel";
            this.BtCancel.Size = new System.Drawing.Size(100, 32);
            this.BtCancel.TabIndex = 54;
            this.BtCancel.Text = "CANCEL";
            this.BtCancel.UseVisualStyleBackColor = true;
            this.BtCancel.Click += new System.EventHandler(this.BtCancel_Click);
            // 
            // BtAbilities
            // 
            this.BtAbilities.Location = new System.Drawing.Point(712, 379);
            this.BtAbilities.Name = "BtAbilities";
            this.BtAbilities.Size = new System.Drawing.Size(100, 32);
            this.BtAbilities.TabIndex = 65;
            this.BtAbilities.Text = "Abilities";
            this.BtAbilities.UseVisualStyleBackColor = true;
            this.BtAbilities.Click += new System.EventHandler(this.BtAbilities_Click);
            // 
            // TxBoxEDMMName
            // 
            this.TxBoxEDMMName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxEDMMName.Location = new System.Drawing.Point(608, 351);
            this.TxBoxEDMMName.Name = "TxBoxEDMMName";
            this.TxBoxEDMMName.Size = new System.Drawing.Size(204, 22);
            this.TxBoxEDMMName.TabIndex = 67;
            // 
            // BtStats
            // 
            this.BtStats.Location = new System.Drawing.Point(732, 468);
            this.BtStats.Name = "BtStats";
            this.BtStats.Size = new System.Drawing.Size(80, 32);
            this.BtStats.TabIndex = 68;
            this.BtStats.Text = "Stats";
            this.BtStats.UseVisualStyleBackColor = true;
            this.BtStats.Click += new System.EventHandler(this.BtStats_Click);
            // 
            // NumID_Base
            // 
            this.NumID_Base.Location = new System.Drawing.Point(608, 131);
            this.NumID_Base.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.NumID_Base.Name = "NumID_Base";
            this.NumID_Base.Size = new System.Drawing.Size(64, 20);
            this.NumID_Base.TabIndex = 69;
            this.NumID_Base.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NumID_Base_KeyDown);
            // 
            // NumID_Awaken
            // 
            this.NumID_Awaken.Location = new System.Drawing.Point(678, 131);
            this.NumID_Awaken.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.NumID_Awaken.Name = "NumID_Awaken";
            this.NumID_Awaken.Size = new System.Drawing.Size(64, 20);
            this.NumID_Awaken.TabIndex = 70;
            this.NumID_Awaken.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NumID_Awaken_KeyDown);
            // 
            // NumID_Bloom
            // 
            this.NumID_Bloom.Location = new System.Drawing.Point(748, 131);
            this.NumID_Bloom.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.NumID_Bloom.Name = "NumID_Bloom";
            this.NumID_Bloom.Size = new System.Drawing.Size(64, 20);
            this.NumID_Bloom.TabIndex = 71;
            this.NumID_Bloom.KeyDown += new System.Windows.Forms.KeyEventHandler(this.NumID_Bloom_KeyDown);
            // 
            // BtSkill
            // 
            this.BtSkill.Location = new System.Drawing.Point(608, 379);
            this.BtSkill.Name = "BtSkill";
            this.BtSkill.Size = new System.Drawing.Size(100, 32);
            this.BtSkill.TabIndex = 73;
            this.BtSkill.Text = "Skill";
            this.BtSkill.UseVisualStyleBackColor = true;
            this.BtSkill.Click += new System.EventHandler(this.BtSkill_Click);
            // 
            // FlowerEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 602);
            this.ControlBox = false;
            this.Controls.Add(this.BtSkill);
            this.Controls.Add(this.PicBoxMain);
            this.Controls.Add(this.NumID_Bloom);
            this.Controls.Add(this.NumID_Awaken);
            this.Controls.Add(this.NumID_Base);
            this.Controls.Add(this.BtStats);
            this.Controls.Add(this.TxBoxEDMMName);
            this.Controls.Add(this.BtAbilities);
            this.Controls.Add(this.BtCancel);
            this.Controls.Add(this.TxBoxInfo00);
            this.Controls.Add(this.NumRarity);
            this.Controls.Add(this.CmBoxNation);
            this.Controls.Add(this.TxBoxENutName);
            this.Controls.Add(this.TxBoxRName);
            this.Controls.Add(this.TxBoxKName);
            this.Controls.Add(this.PicBoxIcon);
            this.Controls.Add(this.BtSelectBloom);
            this.Controls.Add(this.BtSelectAwakened);
            this.Controls.Add(this.BtSelectBase);
            this.Controls.Add(this.TxBoxInfo01);
            this.Controls.Add(this.CmBoxAttackType);
            this.Controls.Add(this.BtOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(840, 640);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(840, 640);
            this.Name = "FlowerEditor";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Flower Editor";
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumRarity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumID_Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumID_Awaken)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumID_Bloom)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtOk;
        private System.Windows.Forms.PictureBox PicBoxMain;
        private System.Windows.Forms.ComboBox CmBoxAttackType;
        private System.Windows.Forms.TextBox TxBoxInfo01;
        private System.Windows.Forms.Button BtSelectBase;
        private System.Windows.Forms.Button BtSelectAwakened;
        private System.Windows.Forms.Button BtSelectBloom;
        private System.Windows.Forms.PictureBox PicBoxIcon;
        private System.Windows.Forms.TextBox TxBoxKName;
        private System.Windows.Forms.TextBox TxBoxRName;
        private System.Windows.Forms.TextBox TxBoxENutName;
        private System.Windows.Forms.ComboBox CmBoxNation;
        private System.Windows.Forms.NumericUpDown NumRarity;
        private System.Windows.Forms.TextBox TxBoxInfo00;
        private System.Windows.Forms.Button BtCancel;
        private System.Windows.Forms.Button BtAbilities;
        private System.Windows.Forms.TextBox TxBoxEDMMName;
        private System.Windows.Forms.Button BtStats;
        private System.Windows.Forms.NumericUpDown NumID_Base;
        private System.Windows.Forms.NumericUpDown NumID_Awaken;
        private System.Windows.Forms.NumericUpDown NumID_Bloom;
        private System.Windows.Forms.Button BtSkill;
    }
}