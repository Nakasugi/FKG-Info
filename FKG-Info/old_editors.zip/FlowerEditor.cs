﻿using System;
using System.Drawing;
using System.Windows.Forms;



namespace FKG_Info
{
    public partial class FlowerEditor : Form
    {
        FlowerInfo Flower;
        FlowerInfo Original;


        bool CreateNew;


        ToolTip TTip;

        //bool    mmove;
        //Point   PosFix, PosNew;



        public FlowerEditor(bool createNew)
        {
            InitializeComponent();

            string TTipText = "Press Enter to auto calculate other IDs";

            TTip = new ToolTip();
            TTip.SetToolTip(NumID_Base, TTipText);
            TTip.SetToolTip(NumID_Awaken, TTipText);
            TTip.SetToolTip(NumID_Bloom, TTipText);


            foreach (string at in FlowerInfo.AttackTypes) CmBoxAttackType.Items.Add(at);
            foreach (string nt in FlowerInfo.Nations) CmBoxNation.Items.Add(nt);


            if (createNew || !Program.DataBase.IsSelected())
            {
                Original = new FlowerInfo();
                CreateNew = true;
            }
            else
            {
                Original = Program.DataBase.GetSelected();
                CreateNew = false;
            }


            //Flower = FlowerInfo.DeepCopy(Original);
            Flower = new FlowerInfo();
            Original.CopyTo(Flower);


            CmBoxAttackType.SelectedIndex = CmBoxAttackType.FindString(Flower.GetAttackType());
            CmBoxNation.SelectedIndex = CmBoxNation.FindString(Flower.GetNation());
            NumRarity.Value = Flower.Rarity;
            TxBoxKName.Text = Flower.Name.Kanji;
            TxBoxRName.Text = Flower.Name.Romaji;
            TxBoxENutName.Text = Flower.Name.EngNutaku;
            TxBoxEDMMName.Text = Flower.Name.EngDMM;

            /*
            TxBoxSkillName.Text = Flower.Skill.GetName();
            NumSkillHits.Value = Flower.Skill.GetHitCount();
            NumSkillTargets.Value = Flower.Skill.GetTargets();
            NumSkillDamage.Value = (decimal)Flower.Skill.getDamage();
            NumSkillChance.Value = Flower.Skill.GetChance();

            ChBoxSkillHPAbsorb.Checked = Flower.Skill.IsHPAbsorb();
            */

            NumID_Base.Value = Flower.ImageBase;
            NumID_Awaken.Value = Flower.ImageAwakened;
            NumID_Bloom.Value = Flower.ImageBloomed;

            SetImages((int)NumID_Base.Value);


        }



        private void BtOk_Click(object sender, EventArgs ev)
        {
            Flower.Name.Romaji = TxBoxRName.Text;
            Flower.Name.EngNutaku = TxBoxENutName.Text;
            Flower.Name.EngDMM = TxBoxEDMMName.Text;
            Flower.Nation = CmBoxNation.SelectedIndex;
            Flower.AttackType=CmBoxAttackType.SelectedIndex;
            Flower.Rarity = (int)NumRarity.Value;

            //Flower.Skill.SetName(TxBoxSkillName.Text);
            //Flower.Skill.Set(NumSkillHits.Value, NumSkillTargets.Value, NumSkillDamage.Value, NumSkillChance.Value, ChBoxSkillHPAbsorb.Checked);

            Flower.ImageBase = (int)NumID_Base.Value;
            Flower.ImageAwakened = (int)NumID_Awaken.Value;
            Flower.ImageBloomed = (int)NumID_Bloom.Value;

            //if (CreateNew && (Flower.Name.Kanji != "")) Program.DataBase.Add(Flower);

            //Original = FlowerInfo.DeepCopy(Flower);

            Flower.CopyTo(Original);
            if (CreateNew) Program.DataBase.Add(Original);
            Program.DataBase.Select(Original);

            Close();
        }


        /*
        private void BtFileselect_Click(object sender, EventArgs ev)
        {
            OpenFileDialog openFDialog = new OpenFileDialog();


            openFDialog.InitialDirectory = Program.WorkFolder; //"F:\\Pictures\\Anime\\FKG\\Img";
            openFDialog.Filter = "png files (*.png)|*.png";
            openFDialog.FilterIndex = 0;
            openFDialog.RestoreDirectory = true;

            if (openFDialog.ShowDialog() == DialogResult.OK)
            {
                System.IO.DirectoryInfo dInfo = new System.IO.DirectoryInfo(openFDialog.FileName);

                string[] s = dInfo.Name.Split('.');
                Flower.Name.Kanji = s[0].Remove(s[0].Length - 2);

                TxBoxKName.Text = Flower.Name.Kanji;
                Flower.Name.AutoRomaji();
                TxBoxRName.Text = Flower.Name.Romaji;

                SetImages((int)NumID_Base.Value);
            }

        }
        */



        private void BtCancel_Click(object sender, EventArgs ev)
        {
            //if (!CreateNew) Program.DataBase.FlowerList.Remove(Flower);

            Close();
        }



        private void BtStats_Click(object sender, EventArgs ev)
        {
            StatsEditor se = new StatsEditor(Flower);
            se.ShowDialog(this);
        }



        private void BtSkill_Click(object sender, EventArgs ev)
        {
            SkillEditor se = new SkillEditor(Flower);
            se.ShowDialog(this);
        }



        private void BtAbilities_Click(object sender, EventArgs ev)
        {
            AbilityEditor ae = new AbilityEditor(Flower);
            ae.ShowDialog(this);
        }



        private void SetImages(int id)
        {
            string fname;
            //PicBoxMain.Image = Flower.GetImage(id, FlowerInfo.ImageTypes.Stand);
            //PicBoxIcon.Image = Flower.GetImage(id, FlowerInfo.ImageTypes.IconLarge);

            //if (PicBoxMain.Image == null)
            //{
            fname = Flower.GetImageTypeName(FlowerInfo.ImageTypes.Stand) + id.ToString();
            Program.ImageLoader.GetImage(fname, SetMainImageCallback);
            //}

            //if (PicBoxIcon.Image == null)
            //{
            fname = Flower.GetImageTypeName(FlowerInfo.ImageTypes.IconLarge) + id.ToString();
            Program.ImageLoader.GetImage(fname, SetIconImageCallback);
            //}
        }


        private void SetMainImageCallback(Image img) { PicBoxMain.Image = img; }
        private void SetIconImageCallback(Image img) { PicBoxIcon.Image = img; }

        private void BtSelectBase_Click(object sender, EventArgs ev)
        {
            SetImages((int)NumID_Base.Value);
        }

        private void BtSelectAwakened_Click(object sender, EventArgs ev)
        {
            SetImages((int)NumID_Awaken.Value);
        }

        private void BtSelectBloomed_Click(object sender, EventArgs ev)
        {
            SetImages((int)NumID_Bloom.Value);
        }



        private void TxBoxKName_TextChanged(object sender, EventArgs ev)
        {
            Flower.Name.Kanji = TxBoxKName.Text;
            Flower.Name.AutoRomaji();
            TxBoxRName.Text = Flower.Name.Romaji;
        }




        private void NumID_Base_KeyDown(object sender, KeyEventArgs ev)
        {
            if (ev.KeyCode == Keys.Enter)
            {
                int idBase = (int)NumID_Base.Value;

                if (idBase < 100000) return;
                if (idBase > 200000) return;

                NumID_Awaken.Value = idBase + 1;
                NumID_Bloom.Value = idBase + 300000;
            }
        }

        private void NumID_Awaken_KeyDown(object sender, KeyEventArgs ev)
        {
            if (ev.KeyCode == Keys.Enter)
            {
                int idAwak = (int)NumID_Awaken.Value;

                if (idAwak < 100000) return;
                if (idAwak > 200000) return;

                NumID_Base.Value = idAwak - 1;
                NumID_Bloom.Value = idAwak + 300000 - 1;
            }
        }

        private void NumID_Bloom_KeyDown(object sender, KeyEventArgs ev)
        {
            if (ev.KeyCode == Keys.Enter)
            {
                int idBloom = (int)NumID_Bloom.Value;

                if (idBloom < 400000) return;
                if (idBloom > 500000) return;

                NumID_Base.Value = idBloom - 300000;
                NumID_Awaken.Value = idBloom - 300000 + 1;
            }
        }
    }
}
