﻿using System;
using System.Windows.Forms;

namespace FKG_Info
{
    public partial class StatsEditor : Form
    {
        FlowerInfo Flower;
        public StatsEditor(FlowerInfo flower)
        {
            InitializeComponent();
            Flower = flower;

            //if (NumHitPoints.Minimum < Flower.HitPoints) NumHitPoints.Value = Flower.HitPoints;
            //if (NumAttack.Minimum < Flower.Attack) NumAttack.Value = Flower.Attack;
            //if (NumDefence.Minimum < Flower.Defence) NumDefence.Value = Flower.Defence;
            //if (NumSpeed.Minimum < Flower.Speed) NumSpeed.Value = Flower.Speed;
        }

        private void BtAccept_Click(object sender, EventArgs ev)
        {
            Flower.SetStats((int)NumHitPoints.Value, (int)NumAttack.Value, (int)NumDefence.Value, (int)NumSpeed.Value);

            this.Close();
        }
    }
}
