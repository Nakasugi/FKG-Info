﻿namespace FKG_Info
{
    partial class FlowerSelectForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LsBoxFlowers = new System.Windows.Forms.ListBox();
            this.BtAll = new System.Windows.Forms.Button();
            this.ChBoxS2 = new System.Windows.Forms.CheckBox();
            this.ChBoxS3 = new System.Windows.Forms.CheckBox();
            this.ChBoxS4 = new System.Windows.Forms.CheckBox();
            this.ChBoxS5 = new System.Windows.Forms.CheckBox();
            this.ChBoxS6 = new System.Windows.Forms.CheckBox();
            this.CmBoxNation = new System.Windows.Forms.ComboBox();
            this.BtOk = new System.Windows.Forms.Button();
            this.BtCancel = new System.Windows.Forms.Button();
            this.CmBoxSort = new System.Windows.Forms.ComboBox();
            this.PicBoxIcon = new System.Windows.Forms.PictureBox();
            this.ChBoxMagic = new System.Windows.Forms.CheckBox();
            this.ChBoxPierce = new System.Windows.Forms.CheckBox();
            this.ChBoxBlunt = new System.Windows.Forms.CheckBox();
            this.ChBoxSlash = new System.Windows.Forms.CheckBox();
            this.ChBoxGame01 = new System.Windows.Forms.CheckBox();
            this.ChBoxGame02 = new System.Windows.Forms.CheckBox();
            this.ChBoxGame03 = new System.Windows.Forms.CheckBox();
            this.CmBoxAbility = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxIcon)).BeginInit();
            this.SuspendLayout();
            // 
            // LsBoxFlowers
            // 
            this.LsBoxFlowers.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.LsBoxFlowers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LsBoxFlowers.FormattingEnabled = true;
            this.LsBoxFlowers.ItemHeight = 16;
            this.LsBoxFlowers.Location = new System.Drawing.Point(12, 13);
            this.LsBoxFlowers.Name = "LsBoxFlowers";
            this.LsBoxFlowers.Size = new System.Drawing.Size(396, 212);
            this.LsBoxFlowers.TabIndex = 0;
            this.LsBoxFlowers.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.LsBox_DrawItem);
            this.LsBoxFlowers.SelectedIndexChanged += new System.EventHandler(this.LsBox_SelectedIndexChanged);
            this.LsBoxFlowers.MouseMove += new System.Windows.Forms.MouseEventHandler(this.LsBox_MouseMove);
            // 
            // BtAll
            // 
            this.BtAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtAll.Location = new System.Drawing.Point(414, 188);
            this.BtAll.Name = "BtAll";
            this.BtAll.Size = new System.Drawing.Size(38, 38);
            this.BtAll.TabIndex = 5;
            this.BtAll.Text = "Inv";
            this.BtAll.UseVisualStyleBackColor = true;
            this.BtAll.Click += new System.EventHandler(this.BtInv_Click);
            // 
            // ChBoxS2
            // 
            this.ChBoxS2.AutoSize = true;
            this.ChBoxS2.Checked = true;
            this.ChBoxS2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChBoxS2.Font = new System.Drawing.Font("Arial Unicode MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChBoxS2.Location = new System.Drawing.Point(127, 231);
            this.ChBoxS2.Margin = new System.Windows.Forms.Padding(0);
            this.ChBoxS2.Name = "ChBoxS2";
            this.ChBoxS2.Size = new System.Drawing.Size(48, 24);
            this.ChBoxS2.TabIndex = 6;
            this.ChBoxS2.Text = "★2";
            this.ChBoxS2.UseVisualStyleBackColor = true;
            this.ChBoxS2.CheckedChanged += new System.EventHandler(this.ChBox_CheckedChanged);
            // 
            // ChBoxS3
            // 
            this.ChBoxS3.AutoSize = true;
            this.ChBoxS3.Checked = true;
            this.ChBoxS3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChBoxS3.Font = new System.Drawing.Font("Arial Unicode MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChBoxS3.Location = new System.Drawing.Point(175, 231);
            this.ChBoxS3.Margin = new System.Windows.Forms.Padding(0);
            this.ChBoxS3.Name = "ChBoxS3";
            this.ChBoxS3.Size = new System.Drawing.Size(48, 24);
            this.ChBoxS3.TabIndex = 7;
            this.ChBoxS3.Text = "★3";
            this.ChBoxS3.UseVisualStyleBackColor = true;
            this.ChBoxS3.CheckedChanged += new System.EventHandler(this.ChBox_CheckedChanged);
            // 
            // ChBoxS4
            // 
            this.ChBoxS4.AutoSize = true;
            this.ChBoxS4.Checked = true;
            this.ChBoxS4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChBoxS4.Font = new System.Drawing.Font("Arial Unicode MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChBoxS4.Location = new System.Drawing.Point(223, 231);
            this.ChBoxS4.Margin = new System.Windows.Forms.Padding(0);
            this.ChBoxS4.Name = "ChBoxS4";
            this.ChBoxS4.Size = new System.Drawing.Size(48, 24);
            this.ChBoxS4.TabIndex = 8;
            this.ChBoxS4.Text = "★4";
            this.ChBoxS4.UseVisualStyleBackColor = true;
            this.ChBoxS4.CheckedChanged += new System.EventHandler(this.ChBox_CheckedChanged);
            // 
            // ChBoxS5
            // 
            this.ChBoxS5.AutoSize = true;
            this.ChBoxS5.Checked = true;
            this.ChBoxS5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChBoxS5.Font = new System.Drawing.Font("Arial Unicode MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChBoxS5.Location = new System.Drawing.Point(271, 231);
            this.ChBoxS5.Margin = new System.Windows.Forms.Padding(0);
            this.ChBoxS5.Name = "ChBoxS5";
            this.ChBoxS5.Size = new System.Drawing.Size(48, 24);
            this.ChBoxS5.TabIndex = 9;
            this.ChBoxS5.Text = "★5";
            this.ChBoxS5.UseVisualStyleBackColor = true;
            this.ChBoxS5.CheckedChanged += new System.EventHandler(this.ChBox_CheckedChanged);
            // 
            // ChBoxS6
            // 
            this.ChBoxS6.AutoSize = true;
            this.ChBoxS6.Checked = true;
            this.ChBoxS6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChBoxS6.Font = new System.Drawing.Font("Arial Unicode MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChBoxS6.Location = new System.Drawing.Point(319, 231);
            this.ChBoxS6.Margin = new System.Windows.Forms.Padding(0);
            this.ChBoxS6.Name = "ChBoxS6";
            this.ChBoxS6.Size = new System.Drawing.Size(48, 24);
            this.ChBoxS6.TabIndex = 10;
            this.ChBoxS6.Text = "★6";
            this.ChBoxS6.UseVisualStyleBackColor = true;
            this.ChBoxS6.CheckedChanged += new System.EventHandler(this.ChBox_CheckedChanged);
            // 
            // CmBoxNation
            // 
            this.CmBoxNation.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmBoxNation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmBoxNation.FormattingEnabled = true;
            this.CmBoxNation.Location = new System.Drawing.Point(127, 258);
            this.CmBoxNation.Name = "CmBoxNation";
            this.CmBoxNation.Size = new System.Drawing.Size(160, 21);
            this.CmBoxNation.TabIndex = 11;
            this.CmBoxNation.SelectedIndexChanged += new System.EventHandler(this.CmBox_SelectedIndexChanged);
            // 
            // BtOk
            // 
            this.BtOk.Enabled = false;
            this.BtOk.Location = new System.Drawing.Point(12, 337);
            this.BtOk.Name = "BtOk";
            this.BtOk.Size = new System.Drawing.Size(120, 36);
            this.BtOk.TabIndex = 12;
            this.BtOk.Text = "OK";
            this.BtOk.UseVisualStyleBackColor = true;
            this.BtOk.Click += new System.EventHandler(this.BtOk_Click);
            // 
            // BtCancel
            // 
            this.BtCancel.Location = new System.Drawing.Point(138, 337);
            this.BtCancel.Name = "BtCancel";
            this.BtCancel.Size = new System.Drawing.Size(120, 36);
            this.BtCancel.TabIndex = 13;
            this.BtCancel.Text = "CANCEL";
            this.BtCancel.UseVisualStyleBackColor = true;
            this.BtCancel.Click += new System.EventHandler(this.BtCancel_Click);
            // 
            // CmBoxSort
            // 
            this.CmBoxSort.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmBoxSort.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmBoxSort.FormattingEnabled = true;
            this.CmBoxSort.Location = new System.Drawing.Point(293, 258);
            this.CmBoxSort.Name = "CmBoxSort";
            this.CmBoxSort.Size = new System.Drawing.Size(159, 21);
            this.CmBoxSort.TabIndex = 14;
            this.CmBoxSort.SelectedIndexChanged += new System.EventHandler(this.CmBox_SelectedIndexChanged);
            // 
            // PicBoxIcon
            // 
            this.PicBoxIcon.Location = new System.Drawing.Point(12, 231);
            this.PicBoxIcon.Name = "PicBoxIcon";
            this.PicBoxIcon.Size = new System.Drawing.Size(100, 100);
            this.PicBoxIcon.TabIndex = 10;
            this.PicBoxIcon.TabStop = false;
            // 
            // ChBoxMagic
            // 
            this.ChBoxMagic.Appearance = System.Windows.Forms.Appearance.Button;
            this.ChBoxMagic.AutoSize = true;
            this.ChBoxMagic.Checked = true;
            this.ChBoxMagic.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChBoxMagic.Image = global::FKG_Info.Properties.Resources.Magic;
            this.ChBoxMagic.Location = new System.Drawing.Point(414, 144);
            this.ChBoxMagic.Name = "ChBoxMagic";
            this.ChBoxMagic.Size = new System.Drawing.Size(38, 38);
            this.ChBoxMagic.TabIndex = 4;
            this.ChBoxMagic.UseVisualStyleBackColor = true;
            this.ChBoxMagic.CheckedChanged += new System.EventHandler(this.ChBox_CheckedChanged);
            // 
            // ChBoxPierce
            // 
            this.ChBoxPierce.Appearance = System.Windows.Forms.Appearance.Button;
            this.ChBoxPierce.AutoSize = true;
            this.ChBoxPierce.Checked = true;
            this.ChBoxPierce.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChBoxPierce.Image = global::FKG_Info.Properties.Resources.Pierce;
            this.ChBoxPierce.Location = new System.Drawing.Point(414, 100);
            this.ChBoxPierce.Name = "ChBoxPierce";
            this.ChBoxPierce.Size = new System.Drawing.Size(38, 38);
            this.ChBoxPierce.TabIndex = 3;
            this.ChBoxPierce.UseVisualStyleBackColor = true;
            this.ChBoxPierce.CheckedChanged += new System.EventHandler(this.ChBox_CheckedChanged);
            // 
            // ChBoxBlunt
            // 
            this.ChBoxBlunt.Appearance = System.Windows.Forms.Appearance.Button;
            this.ChBoxBlunt.AutoSize = true;
            this.ChBoxBlunt.Checked = true;
            this.ChBoxBlunt.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChBoxBlunt.Image = global::FKG_Info.Properties.Resources.Blunt;
            this.ChBoxBlunt.Location = new System.Drawing.Point(414, 56);
            this.ChBoxBlunt.Name = "ChBoxBlunt";
            this.ChBoxBlunt.Size = new System.Drawing.Size(38, 38);
            this.ChBoxBlunt.TabIndex = 2;
            this.ChBoxBlunt.UseVisualStyleBackColor = true;
            this.ChBoxBlunt.CheckedChanged += new System.EventHandler(this.ChBox_CheckedChanged);
            // 
            // ChBoxSlash
            // 
            this.ChBoxSlash.Appearance = System.Windows.Forms.Appearance.Button;
            this.ChBoxSlash.AutoSize = true;
            this.ChBoxSlash.Checked = true;
            this.ChBoxSlash.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ChBoxSlash.Image = global::FKG_Info.Properties.Resources.Slash;
            this.ChBoxSlash.Location = new System.Drawing.Point(414, 12);
            this.ChBoxSlash.Name = "ChBoxSlash";
            this.ChBoxSlash.Size = new System.Drawing.Size(38, 38);
            this.ChBoxSlash.TabIndex = 1;
            this.ChBoxSlash.UseVisualStyleBackColor = true;
            this.ChBoxSlash.CheckedChanged += new System.EventHandler(this.ChBox_CheckedChanged);
            // 
            // ChBoxGame01
            // 
            this.ChBoxGame01.AutoSize = true;
            this.ChBoxGame01.Checked = true;
            this.ChBoxGame01.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.ChBoxGame01.Location = new System.Drawing.Point(294, 289);
            this.ChBoxGame01.Name = "ChBoxGame01";
            this.ChBoxGame01.Size = new System.Drawing.Size(66, 17);
            this.ChBoxGame01.TabIndex = 15;
            this.ChBoxGame01.Text = "Game01";
            this.ChBoxGame01.ThreeState = true;
            this.ChBoxGame01.UseVisualStyleBackColor = true;
            this.ChBoxGame01.CheckStateChanged += new System.EventHandler(this.ChBox_CheckedStateChanged);
            // 
            // ChBoxGame02
            // 
            this.ChBoxGame02.AutoSize = true;
            this.ChBoxGame02.Checked = true;
            this.ChBoxGame02.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.ChBoxGame02.Location = new System.Drawing.Point(294, 312);
            this.ChBoxGame02.Name = "ChBoxGame02";
            this.ChBoxGame02.Size = new System.Drawing.Size(66, 17);
            this.ChBoxGame02.TabIndex = 16;
            this.ChBoxGame02.Text = "Game02";
            this.ChBoxGame02.ThreeState = true;
            this.ChBoxGame02.UseVisualStyleBackColor = true;
            this.ChBoxGame02.CheckStateChanged += new System.EventHandler(this.ChBox_CheckedStateChanged);
            // 
            // ChBoxGame03
            // 
            this.ChBoxGame03.AutoSize = true;
            this.ChBoxGame03.Checked = true;
            this.ChBoxGame03.CheckState = System.Windows.Forms.CheckState.Indeterminate;
            this.ChBoxGame03.Location = new System.Drawing.Point(294, 335);
            this.ChBoxGame03.Name = "ChBoxGame03";
            this.ChBoxGame03.Size = new System.Drawing.Size(66, 17);
            this.ChBoxGame03.TabIndex = 17;
            this.ChBoxGame03.Text = "Game03";
            this.ChBoxGame03.ThreeState = true;
            this.ChBoxGame03.UseVisualStyleBackColor = true;
            this.ChBoxGame03.CheckStateChanged += new System.EventHandler(this.ChBox_CheckedStateChanged);
            // 
            // CmBoxAbility
            // 
            this.CmBoxAbility.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CmBoxAbility.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CmBoxAbility.FormattingEnabled = true;
            this.CmBoxAbility.Location = new System.Drawing.Point(127, 285);
            this.CmBoxAbility.Name = "CmBoxAbility";
            this.CmBoxAbility.Size = new System.Drawing.Size(160, 21);
            this.CmBoxAbility.TabIndex = 18;
            this.CmBoxAbility.SelectedIndexChanged += new System.EventHandler(this.CmBoxAbility_SelectedIndexChanged);
            // 
            // FlowerSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 386);
            this.ControlBox = false;
            this.Controls.Add(this.CmBoxAbility);
            this.Controls.Add(this.ChBoxGame03);
            this.Controls.Add(this.ChBoxGame02);
            this.Controls.Add(this.ChBoxGame01);
            this.Controls.Add(this.CmBoxSort);
            this.Controls.Add(this.BtCancel);
            this.Controls.Add(this.BtOk);
            this.Controls.Add(this.CmBoxNation);
            this.Controls.Add(this.ChBoxS6);
            this.Controls.Add(this.ChBoxS5);
            this.Controls.Add(this.ChBoxS4);
            this.Controls.Add(this.ChBoxS3);
            this.Controls.Add(this.ChBoxS2);
            this.Controls.Add(this.PicBoxIcon);
            this.Controls.Add(this.BtAll);
            this.Controls.Add(this.ChBoxMagic);
            this.Controls.Add(this.ChBoxPierce);
            this.Controls.Add(this.ChBoxBlunt);
            this.Controls.Add(this.ChBoxSlash);
            this.Controls.Add(this.LsBoxFlowers);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FlowerSelect";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FlowerSelect";
            ((System.ComponentModel.ISupportInitialize)(this.PicBoxIcon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox LsBoxFlowers;
        private System.Windows.Forms.CheckBox ChBoxSlash;
        private System.Windows.Forms.CheckBox ChBoxBlunt;
        private System.Windows.Forms.CheckBox ChBoxPierce;
        private System.Windows.Forms.CheckBox ChBoxMagic;
        private System.Windows.Forms.Button BtAll;
        private System.Windows.Forms.PictureBox PicBoxIcon;
        private System.Windows.Forms.CheckBox ChBoxS2;
        private System.Windows.Forms.CheckBox ChBoxS3;
        private System.Windows.Forms.CheckBox ChBoxS4;
        private System.Windows.Forms.CheckBox ChBoxS5;
        private System.Windows.Forms.CheckBox ChBoxS6;
        private System.Windows.Forms.ComboBox CmBoxNation;
        private System.Windows.Forms.Button BtOk;
        private System.Windows.Forms.Button BtCancel;
        private System.Windows.Forms.ComboBox CmBoxSort;
        private System.Windows.Forms.CheckBox ChBoxGame01;
        private System.Windows.Forms.CheckBox ChBoxGame02;
        private System.Windows.Forms.CheckBox ChBoxGame03;
        private System.Windows.Forms.ComboBox CmBoxAbility;
    }
}