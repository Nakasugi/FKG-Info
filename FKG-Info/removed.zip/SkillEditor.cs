﻿using System;
using System.Windows.Forms;

namespace FKG_Info
{
    public partial class SkillEditor : Form
    {
        FlowerInfo Flower;



        public SkillEditor(FlowerInfo flower)
        {
            InitializeComponent();

            Flower = flower;
            //TxBoxKName.Text = Flower.Skill.Name.Kanji;
            //TxBoxRName.Text = Flower.Skill.Name.Romaji;
            //TxBoxNName.Text = Flower.Skill.Name.EngNutaku;
            //TxBoxDName.Text = Flower.Skill.Name.EngDMM;

            //NumTargets.Value = Flower.Skill.Targets;
            //NumHits.Value = Flower.Skill.HitCount;
            //NumDamage.Value = 0.1m * (decimal)Flower.Skill.Damage;
            //NumChance.Value = Flower.Skill.Chance;

            //ChBoxAbsorbHP.Checked = Flower.Skill.HPAbsorb;
        }



        private void BtOk_Click(object sender, EventArgs ev)
        {
            //Flower.Skill.Name.Kanji = TxBoxKName.Text;
            //Flower.Skill.Name.Romaji = TxBoxRName.Text;
            //Flower.Skill.Name.EngNutaku = TxBoxNName.Text;
            //Flower.Skill.Name.EngDMM = TxBoxDName.Text;

            //Flower.Skill.Targets = (int)NumTargets.Value;
            //Flower.Skill.HitCount = (int)NumHits.Value;
            //Flower.Skill.Damage = (int)(10.0m * NumDamage.Value);
            //Flower.Skill.Chance = (int)NumChance.Value;

            //Flower.Skill.HPAbsorb = ChBoxAbsorbHP.Checked;

            Close();
        }



        private void BtCancel_Click(object sender, EventArgs ev)
        {
            Close();
        }
    }
}
