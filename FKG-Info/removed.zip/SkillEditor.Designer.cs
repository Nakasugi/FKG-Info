﻿namespace FKG_Info
{
    partial class SkillEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxBoxKName = new System.Windows.Forms.TextBox();
            this.TxBoxRName = new System.Windows.Forms.TextBox();
            this.TxBoxNName = new System.Windows.Forms.TextBox();
            this.TxBoxDName = new System.Windows.Forms.TextBox();
            this.NumTargets = new System.Windows.Forms.NumericUpDown();
            this.NumHits = new System.Windows.Forms.NumericUpDown();
            this.NumDamage = new System.Windows.Forms.NumericUpDown();
            this.NumChance = new System.Windows.Forms.NumericUpDown();
            this._TxBoxInto01 = new System.Windows.Forms.TextBox();
            this._TxBoxInto02 = new System.Windows.Forms.TextBox();
            this._TxBoxInto03 = new System.Windows.Forms.TextBox();
            this._TxBoxInto04 = new System.Windows.Forms.TextBox();
            this._TxBoxInto05 = new System.Windows.Forms.TextBox();
            this._TxBoxInto06 = new System.Windows.Forms.TextBox();
            this._TxBoxInto07 = new System.Windows.Forms.TextBox();
            this._TxBoxInto08 = new System.Windows.Forms.TextBox();
            this.BtCancel = new System.Windows.Forms.Button();
            this.BtOk = new System.Windows.Forms.Button();
            this.ChBoxAbsorbHP = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.NumTargets)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumHits)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDamage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumChance)).BeginInit();
            this.SuspendLayout();
            // 
            // TxBoxKName
            // 
            this.TxBoxKName.Location = new System.Drawing.Point(12, 12);
            this.TxBoxKName.Name = "TxBoxKName";
            this.TxBoxKName.Size = new System.Drawing.Size(320, 20);
            this.TxBoxKName.TabIndex = 0;
            // 
            // TxBoxRName
            // 
            this.TxBoxRName.Location = new System.Drawing.Point(12, 38);
            this.TxBoxRName.Name = "TxBoxRName";
            this.TxBoxRName.Size = new System.Drawing.Size(320, 20);
            this.TxBoxRName.TabIndex = 1;
            // 
            // TxBoxNName
            // 
            this.TxBoxNName.Location = new System.Drawing.Point(12, 64);
            this.TxBoxNName.Name = "TxBoxNName";
            this.TxBoxNName.Size = new System.Drawing.Size(320, 20);
            this.TxBoxNName.TabIndex = 2;
            // 
            // TxBoxDName
            // 
            this.TxBoxDName.Location = new System.Drawing.Point(12, 90);
            this.TxBoxDName.Name = "TxBoxDName";
            this.TxBoxDName.Size = new System.Drawing.Size(320, 20);
            this.TxBoxDName.TabIndex = 3;
            // 
            // NumTargets
            // 
            this.NumTargets.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumTargets.Location = new System.Drawing.Point(12, 129);
            this.NumTargets.Maximum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.NumTargets.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumTargets.Name = "NumTargets";
            this.NumTargets.Size = new System.Drawing.Size(40, 22);
            this.NumTargets.TabIndex = 4;
            this.NumTargets.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumTargets.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // NumHits
            // 
            this.NumHits.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumHits.Location = new System.Drawing.Point(12, 157);
            this.NumHits.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.NumHits.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumHits.Name = "NumHits";
            this.NumHits.Size = new System.Drawing.Size(40, 22);
            this.NumHits.TabIndex = 5;
            this.NumHits.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumHits.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // NumDamage
            // 
            this.NumDamage.DecimalPlaces = 1;
            this.NumDamage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumDamage.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.NumDamage.Location = new System.Drawing.Point(12, 185);
            this.NumDamage.Name = "NumDamage";
            this.NumDamage.Size = new System.Drawing.Size(40, 22);
            this.NumDamage.TabIndex = 6;
            this.NumDamage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumDamage.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // NumChance
            // 
            this.NumChance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumChance.Location = new System.Drawing.Point(12, 213);
            this.NumChance.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumChance.Name = "NumChance";
            this.NumChance.Size = new System.Drawing.Size(40, 22);
            this.NumChance.TabIndex = 7;
            this.NumChance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumChance.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // _TxBoxInto01
            // 
            this._TxBoxInto01.Cursor = System.Windows.Forms.Cursors.Arrow;
            this._TxBoxInto01.Location = new System.Drawing.Point(338, 12);
            this._TxBoxInto01.Name = "_TxBoxInto01";
            this._TxBoxInto01.ReadOnly = true;
            this._TxBoxInto01.Size = new System.Drawing.Size(80, 20);
            this._TxBoxInto01.TabIndex = 99;
            this._TxBoxInto01.TabStop = false;
            this._TxBoxInto01.Text = "Kanji";
            // 
            // _TxBoxInto02
            // 
            this._TxBoxInto02.Cursor = System.Windows.Forms.Cursors.Arrow;
            this._TxBoxInto02.Location = new System.Drawing.Point(338, 38);
            this._TxBoxInto02.Name = "_TxBoxInto02";
            this._TxBoxInto02.ReadOnly = true;
            this._TxBoxInto02.Size = new System.Drawing.Size(80, 20);
            this._TxBoxInto02.TabIndex = 99;
            this._TxBoxInto02.TabStop = false;
            this._TxBoxInto02.Text = "Romaji";
            // 
            // _TxBoxInto03
            // 
            this._TxBoxInto03.Cursor = System.Windows.Forms.Cursors.Arrow;
            this._TxBoxInto03.Location = new System.Drawing.Point(338, 64);
            this._TxBoxInto03.Name = "_TxBoxInto03";
            this._TxBoxInto03.ReadOnly = true;
            this._TxBoxInto03.Size = new System.Drawing.Size(80, 20);
            this._TxBoxInto03.TabIndex = 99;
            this._TxBoxInto03.TabStop = false;
            this._TxBoxInto03.Text = "Eng. Nutaku";
            // 
            // _TxBoxInto04
            // 
            this._TxBoxInto04.Cursor = System.Windows.Forms.Cursors.Arrow;
            this._TxBoxInto04.Location = new System.Drawing.Point(338, 90);
            this._TxBoxInto04.Name = "_TxBoxInto04";
            this._TxBoxInto04.ReadOnly = true;
            this._TxBoxInto04.Size = new System.Drawing.Size(80, 20);
            this._TxBoxInto04.TabIndex = 99;
            this._TxBoxInto04.TabStop = false;
            this._TxBoxInto04.Text = "Eng. DMM";
            // 
            // _TxBoxInto05
            // 
            this._TxBoxInto05.Cursor = System.Windows.Forms.Cursors.Arrow;
            this._TxBoxInto05.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this._TxBoxInto05.Location = new System.Drawing.Point(58, 129);
            this._TxBoxInto05.Name = "_TxBoxInto05";
            this._TxBoxInto05.ReadOnly = true;
            this._TxBoxInto05.Size = new System.Drawing.Size(128, 22);
            this._TxBoxInto05.TabIndex = 99;
            this._TxBoxInto05.TabStop = false;
            this._TxBoxInto05.Text = "Targets";
            // 
            // _TxBoxInto06
            // 
            this._TxBoxInto06.Cursor = System.Windows.Forms.Cursors.Arrow;
            this._TxBoxInto06.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this._TxBoxInto06.Location = new System.Drawing.Point(58, 157);
            this._TxBoxInto06.Name = "_TxBoxInto06";
            this._TxBoxInto06.ReadOnly = true;
            this._TxBoxInto06.Size = new System.Drawing.Size(128, 22);
            this._TxBoxInto06.TabIndex = 99;
            this._TxBoxInto06.TabStop = false;
            this._TxBoxInto06.Text = "Hits";
            // 
            // _TxBoxInto07
            // 
            this._TxBoxInto07.Cursor = System.Windows.Forms.Cursors.Arrow;
            this._TxBoxInto07.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this._TxBoxInto07.Location = new System.Drawing.Point(58, 185);
            this._TxBoxInto07.Name = "_TxBoxInto07";
            this._TxBoxInto07.ReadOnly = true;
            this._TxBoxInto07.Size = new System.Drawing.Size(128, 22);
            this._TxBoxInto07.TabIndex = 99;
            this._TxBoxInto07.TabStop = false;
            this._TxBoxInto07.Text = "Damage (Mul)";
            // 
            // _TxBoxInto08
            // 
            this._TxBoxInto08.Cursor = System.Windows.Forms.Cursors.Arrow;
            this._TxBoxInto08.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this._TxBoxInto08.Location = new System.Drawing.Point(58, 213);
            this._TxBoxInto08.Name = "_TxBoxInto08";
            this._TxBoxInto08.ReadOnly = true;
            this._TxBoxInto08.Size = new System.Drawing.Size(128, 22);
            this._TxBoxInto08.TabIndex = 99;
            this._TxBoxInto08.TabStop = false;
            this._TxBoxInto08.Text = "Chance (%)";
            // 
            // BtCancel
            // 
            this.BtCancel.Location = new System.Drawing.Point(252, 203);
            this.BtCancel.Name = "BtCancel";
            this.BtCancel.Size = new System.Drawing.Size(80, 32);
            this.BtCancel.TabIndex = 8;
            this.BtCancel.Text = "CANCEL";
            this.BtCancel.UseVisualStyleBackColor = true;
            this.BtCancel.Click += new System.EventHandler(this.BtCancel_Click);
            // 
            // BtOk
            // 
            this.BtOk.Location = new System.Drawing.Point(338, 203);
            this.BtOk.Name = "BtOk";
            this.BtOk.Size = new System.Drawing.Size(80, 32);
            this.BtOk.TabIndex = 9;
            this.BtOk.Text = "OK";
            this.BtOk.UseVisualStyleBackColor = true;
            this.BtOk.Click += new System.EventHandler(this.BtOk_Click);
            // 
            // ChBoxAbsorbHP
            // 
            this.ChBoxAbsorbHP.AutoSize = true;
            this.ChBoxAbsorbHP.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ChBoxAbsorbHP.Location = new System.Drawing.Point(220, 129);
            this.ChBoxAbsorbHP.Name = "ChBoxAbsorbHP";
            this.ChBoxAbsorbHP.Size = new System.Drawing.Size(93, 20);
            this.ChBoxAbsorbHP.TabIndex = 100;
            this.ChBoxAbsorbHP.Text = "Absorb HP";
            this.ChBoxAbsorbHP.UseVisualStyleBackColor = true;
            // 
            // SkillEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 244);
            this.ControlBox = false;
            this.Controls.Add(this.ChBoxAbsorbHP);
            this.Controls.Add(this.BtOk);
            this.Controls.Add(this.BtCancel);
            this.Controls.Add(this._TxBoxInto08);
            this.Controls.Add(this._TxBoxInto07);
            this.Controls.Add(this._TxBoxInto06);
            this.Controls.Add(this._TxBoxInto05);
            this.Controls.Add(this._TxBoxInto04);
            this.Controls.Add(this._TxBoxInto03);
            this.Controls.Add(this._TxBoxInto02);
            this.Controls.Add(this._TxBoxInto01);
            this.Controls.Add(this.NumChance);
            this.Controls.Add(this.NumDamage);
            this.Controls.Add(this.NumHits);
            this.Controls.Add(this.NumTargets);
            this.Controls.Add(this.TxBoxDName);
            this.Controls.Add(this.TxBoxNName);
            this.Controls.Add(this.TxBoxRName);
            this.Controls.Add(this.TxBoxKName);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SkillEditor";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Skill Editor";
            ((System.ComponentModel.ISupportInitialize)(this.NumTargets)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumHits)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDamage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumChance)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxBoxKName;
        private System.Windows.Forms.TextBox TxBoxRName;
        private System.Windows.Forms.TextBox TxBoxNName;
        private System.Windows.Forms.TextBox TxBoxDName;
        private System.Windows.Forms.NumericUpDown NumTargets;
        private System.Windows.Forms.NumericUpDown NumHits;
        private System.Windows.Forms.NumericUpDown NumDamage;
        private System.Windows.Forms.NumericUpDown NumChance;
        private System.Windows.Forms.TextBox _TxBoxInto01;
        private System.Windows.Forms.TextBox _TxBoxInto02;
        private System.Windows.Forms.TextBox _TxBoxInto03;
        private System.Windows.Forms.TextBox _TxBoxInto04;
        private System.Windows.Forms.TextBox _TxBoxInto05;
        private System.Windows.Forms.TextBox _TxBoxInto06;
        private System.Windows.Forms.TextBox _TxBoxInto07;
        private System.Windows.Forms.TextBox _TxBoxInto08;
        private System.Windows.Forms.Button BtCancel;
        private System.Windows.Forms.Button BtOk;
        private System.Windows.Forms.CheckBox ChBoxAbsorbHP;
    }
}