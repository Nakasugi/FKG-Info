﻿namespace FKG_Info
{
    partial class AbilityEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtOk = new System.Windows.Forms.Button();
            this.NumBPow01 = new System.Windows.Forms.NumericUpDown();
            this.TxBoxInfo01 = new System.Windows.Forms.TextBox();
            this.TxBoxInfo03 = new System.Windows.Forms.TextBox();
            this.NumBPow02 = new System.Windows.Forms.NumericUpDown();
            this.BtCancel = new System.Windows.Forms.Button();
            this.TxBoxInfo02 = new System.Windows.Forms.TextBox();
            this.NumRPow01 = new System.Windows.Forms.NumericUpDown();
            this.NumRPow02 = new System.Windows.Forms.NumericUpDown();
            this.TxBoxInfo04 = new System.Windows.Forms.TextBox();
            this.TxBoxFullInfo01 = new System.Windows.Forms.TextBox();
            this.TxBoxFullInfo02 = new System.Windows.Forms.TextBox();
            this.LsBoxType01 = new System.Windows.Forms.ListBox();
            this.LsBoxType02 = new System.Windows.Forms.ListBox();
            this.BtGenerate01 = new System.Windows.Forms.Button();
            this.BtGenerate02 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NumBPow01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumBPow02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumRPow01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumRPow02)).BeginInit();
            this.SuspendLayout();
            // 
            // BtOk
            // 
            this.BtOk.Location = new System.Drawing.Point(12, 369);
            this.BtOk.Name = "BtOk";
            this.BtOk.Size = new System.Drawing.Size(120, 32);
            this.BtOk.TabIndex = 0;
            this.BtOk.Text = "OK";
            this.BtOk.UseVisualStyleBackColor = true;
            this.BtOk.Click += new System.EventHandler(this.BtOk_Click);
            // 
            // NumBPow01
            // 
            this.NumBPow01.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumBPow01.Location = new System.Drawing.Point(192, 104);
            this.NumBPow01.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumBPow01.Name = "NumBPow01";
            this.NumBPow01.Size = new System.Drawing.Size(58, 21);
            this.NumBPow01.TabIndex = 64;
            // 
            // TxBoxInfo01
            // 
            this.TxBoxInfo01.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxBoxInfo01.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxBoxInfo01.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxInfo01.Location = new System.Drawing.Point(192, 82);
            this.TxBoxInfo01.Multiline = true;
            this.TxBoxInfo01.Name = "TxBoxInfo01";
            this.TxBoxInfo01.ReadOnly = true;
            this.TxBoxInfo01.Size = new System.Drawing.Size(80, 16);
            this.TxBoxInfo01.TabIndex = 65;
            this.TxBoxInfo01.TabStop = false;
            this.TxBoxInfo01.Text = "Base Power:";
            // 
            // TxBoxInfo03
            // 
            this.TxBoxInfo03.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxBoxInfo03.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxBoxInfo03.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxInfo03.Location = new System.Drawing.Point(463, 82);
            this.TxBoxInfo03.Multiline = true;
            this.TxBoxInfo03.Name = "TxBoxInfo03";
            this.TxBoxInfo03.ReadOnly = true;
            this.TxBoxInfo03.Size = new System.Drawing.Size(80, 16);
            this.TxBoxInfo03.TabIndex = 69;
            this.TxBoxInfo03.TabStop = false;
            this.TxBoxInfo03.Text = "Base Power:";
            // 
            // NumBPow02
            // 
            this.NumBPow02.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumBPow02.Location = new System.Drawing.Point(463, 104);
            this.NumBPow02.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumBPow02.Name = "NumBPow02";
            this.NumBPow02.Size = new System.Drawing.Size(58, 21);
            this.NumBPow02.TabIndex = 68;
            // 
            // BtCancel
            // 
            this.BtCancel.Location = new System.Drawing.Point(185, 369);
            this.BtCancel.Name = "BtCancel";
            this.BtCancel.Size = new System.Drawing.Size(120, 32);
            this.BtCancel.TabIndex = 71;
            this.BtCancel.Text = "CANCEL";
            this.BtCancel.UseVisualStyleBackColor = true;
            this.BtCancel.Click += new System.EventHandler(this.BtCancel_Click);
            // 
            // TxBoxInfo02
            // 
            this.TxBoxInfo02.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxBoxInfo02.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxBoxInfo02.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxInfo02.Location = new System.Drawing.Point(192, 131);
            this.TxBoxInfo02.Multiline = true;
            this.TxBoxInfo02.Name = "TxBoxInfo02";
            this.TxBoxInfo02.ReadOnly = true;
            this.TxBoxInfo02.Size = new System.Drawing.Size(80, 16);
            this.TxBoxInfo02.TabIndex = 72;
            this.TxBoxInfo02.TabStop = false;
            this.TxBoxInfo02.Text = "Raid Power:";
            // 
            // NumRPow01
            // 
            this.NumRPow01.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumRPow01.Location = new System.Drawing.Point(192, 153);
            this.NumRPow01.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumRPow01.Name = "NumRPow01";
            this.NumRPow01.Size = new System.Drawing.Size(58, 21);
            this.NumRPow01.TabIndex = 73;
            // 
            // NumRPow02
            // 
            this.NumRPow02.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumRPow02.Location = new System.Drawing.Point(463, 153);
            this.NumRPow02.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.NumRPow02.Name = "NumRPow02";
            this.NumRPow02.Size = new System.Drawing.Size(58, 21);
            this.NumRPow02.TabIndex = 74;
            // 
            // TxBoxInfo04
            // 
            this.TxBoxInfo04.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxBoxInfo04.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxBoxInfo04.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxInfo04.Location = new System.Drawing.Point(463, 131);
            this.TxBoxInfo04.Multiline = true;
            this.TxBoxInfo04.Name = "TxBoxInfo04";
            this.TxBoxInfo04.ReadOnly = true;
            this.TxBoxInfo04.Size = new System.Drawing.Size(80, 16);
            this.TxBoxInfo04.TabIndex = 75;
            this.TxBoxInfo04.TabStop = false;
            this.TxBoxInfo04.Text = "Raid Power:";
            // 
            // TxBoxFullInfo01
            // 
            this.TxBoxFullInfo01.Location = new System.Drawing.Point(12, 12);
            this.TxBoxFullInfo01.Multiline = true;
            this.TxBoxFullInfo01.Name = "TxBoxFullInfo01";
            this.TxBoxFullInfo01.Size = new System.Drawing.Size(260, 64);
            this.TxBoxFullInfo01.TabIndex = 76;
            // 
            // TxBoxFullInfo02
            // 
            this.TxBoxFullInfo02.Location = new System.Drawing.Point(283, 12);
            this.TxBoxFullInfo02.Multiline = true;
            this.TxBoxFullInfo02.Name = "TxBoxFullInfo02";
            this.TxBoxFullInfo02.Size = new System.Drawing.Size(260, 64);
            this.TxBoxFullInfo02.TabIndex = 77;
            // 
            // LsBoxType01
            // 
            this.LsBoxType01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LsBoxType01.FormattingEnabled = true;
            this.LsBoxType01.Location = new System.Drawing.Point(12, 82);
            this.LsBoxType01.Name = "LsBoxType01";
            this.LsBoxType01.ScrollAlwaysVisible = true;
            this.LsBoxType01.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.LsBoxType01.Size = new System.Drawing.Size(174, 145);
            this.LsBoxType01.TabIndex = 78;
            this.LsBoxType01.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LsBoxType01_MouseClick);
            // 
            // LsBoxType02
            // 
            this.LsBoxType02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LsBoxType02.FormattingEnabled = true;
            this.LsBoxType02.Location = new System.Drawing.Point(283, 82);
            this.LsBoxType02.Name = "LsBoxType02";
            this.LsBoxType02.ScrollAlwaysVisible = true;
            this.LsBoxType02.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.LsBoxType02.Size = new System.Drawing.Size(174, 145);
            this.LsBoxType02.TabIndex = 79;
            this.LsBoxType02.MouseClick += new System.Windows.Forms.MouseEventHandler(this.LsBoxType02_MouseClick);
            // 
            // BtGenerate01
            // 
            this.BtGenerate01.Location = new System.Drawing.Point(192, 195);
            this.BtGenerate01.Name = "BtGenerate01";
            this.BtGenerate01.Size = new System.Drawing.Size(80, 32);
            this.BtGenerate01.TabIndex = 80;
            this.BtGenerate01.Text = "Generate";
            this.BtGenerate01.UseVisualStyleBackColor = true;
            this.BtGenerate01.Click += new System.EventHandler(this.BtGenerate01_Click);
            // 
            // BtGenerate02
            // 
            this.BtGenerate02.Location = new System.Drawing.Point(463, 195);
            this.BtGenerate02.Name = "BtGenerate02";
            this.BtGenerate02.Size = new System.Drawing.Size(80, 32);
            this.BtGenerate02.TabIndex = 81;
            this.BtGenerate02.Text = "Generate";
            this.BtGenerate02.UseVisualStyleBackColor = true;
            this.BtGenerate02.Click += new System.EventHandler(this.BtGenerate02_Click);
            // 
            // AbilityEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(552, 409);
            this.ControlBox = false;
            this.Controls.Add(this.BtGenerate02);
            this.Controls.Add(this.BtGenerate01);
            this.Controls.Add(this.LsBoxType02);
            this.Controls.Add(this.LsBoxType01);
            this.Controls.Add(this.TxBoxFullInfo02);
            this.Controls.Add(this.TxBoxFullInfo01);
            this.Controls.Add(this.TxBoxInfo04);
            this.Controls.Add(this.NumRPow02);
            this.Controls.Add(this.NumRPow01);
            this.Controls.Add(this.TxBoxInfo02);
            this.Controls.Add(this.BtCancel);
            this.Controls.Add(this.TxBoxInfo03);
            this.Controls.Add(this.NumBPow02);
            this.Controls.Add(this.TxBoxInfo01);
            this.Controls.Add(this.NumBPow01);
            this.Controls.Add(this.BtOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AbilityEditor";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Ability Editor";
            ((System.ComponentModel.ISupportInitialize)(this.NumBPow01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumBPow02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumRPow01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumRPow02)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtOk;
        private System.Windows.Forms.NumericUpDown NumBPow01;
        private System.Windows.Forms.TextBox TxBoxInfo01;
        private System.Windows.Forms.TextBox TxBoxInfo03;
        private System.Windows.Forms.NumericUpDown NumBPow02;
        private System.Windows.Forms.Button BtCancel;
        private System.Windows.Forms.TextBox TxBoxInfo02;
        private System.Windows.Forms.NumericUpDown NumRPow01;
        private System.Windows.Forms.NumericUpDown NumRPow02;
        private System.Windows.Forms.TextBox TxBoxInfo04;
        private System.Windows.Forms.TextBox TxBoxFullInfo01;
        private System.Windows.Forms.TextBox TxBoxFullInfo02;
        private System.Windows.Forms.ListBox LsBoxType01;
        private System.Windows.Forms.ListBox LsBoxType02;
        private System.Windows.Forms.Button BtGenerate01;
        private System.Windows.Forms.Button BtGenerate02;
    }
}