﻿namespace FKG_Info
{
    partial class StatsEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxBoxAttack = new System.Windows.Forms.TextBox();
            this.NumAttack = new System.Windows.Forms.NumericUpDown();
            this.NumDefence = new System.Windows.Forms.NumericUpDown();
            this.TxBoxDefence = new System.Windows.Forms.TextBox();
            this.NumSpeed = new System.Windows.Forms.NumericUpDown();
            this.TxBoxSpeed = new System.Windows.Forms.TextBox();
            this.NumHitPoints = new System.Windows.Forms.NumericUpDown();
            this.TxBoxHitPoints = new System.Windows.Forms.TextBox();
            this.BtAccept = new System.Windows.Forms.Button();
            this.BtCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.NumAttack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDefence)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumHitPoints)).BeginInit();
            this.SuspendLayout();
            // 
            // TxBoxAttack
            // 
            this.TxBoxAttack.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxBoxAttack.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxBoxAttack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxAttack.Location = new System.Drawing.Point(155, 12);
            this.TxBoxAttack.Name = "TxBoxAttack";
            this.TxBoxAttack.ReadOnly = true;
            this.TxBoxAttack.Size = new System.Drawing.Size(120, 14);
            this.TxBoxAttack.TabIndex = 0;
            this.TxBoxAttack.TabStop = false;
            this.TxBoxAttack.Text = "Attack";
            this.TxBoxAttack.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NumAttack
            // 
            this.NumAttack.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumAttack.Location = new System.Drawing.Point(155, 32);
            this.NumAttack.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.NumAttack.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.NumAttack.Name = "NumAttack";
            this.NumAttack.Size = new System.Drawing.Size(120, 21);
            this.NumAttack.TabIndex = 2;
            this.NumAttack.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // NumDefence
            // 
            this.NumDefence.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumDefence.Location = new System.Drawing.Point(12, 79);
            this.NumDefence.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.NumDefence.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.NumDefence.Name = "NumDefence";
            this.NumDefence.Size = new System.Drawing.Size(120, 21);
            this.NumDefence.TabIndex = 4;
            this.NumDefence.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // TxBoxDefence
            // 
            this.TxBoxDefence.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxBoxDefence.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxBoxDefence.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxDefence.Location = new System.Drawing.Point(12, 59);
            this.TxBoxDefence.Name = "TxBoxDefence";
            this.TxBoxDefence.ReadOnly = true;
            this.TxBoxDefence.Size = new System.Drawing.Size(120, 14);
            this.TxBoxDefence.TabIndex = 0;
            this.TxBoxDefence.TabStop = false;
            this.TxBoxDefence.Text = "Defence";
            this.TxBoxDefence.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NumSpeed
            // 
            this.NumSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumSpeed.Location = new System.Drawing.Point(155, 79);
            this.NumSpeed.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.NumSpeed.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.NumSpeed.Name = "NumSpeed";
            this.NumSpeed.Size = new System.Drawing.Size(120, 21);
            this.NumSpeed.TabIndex = 3;
            this.NumSpeed.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // TxBoxSpeed
            // 
            this.TxBoxSpeed.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxBoxSpeed.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxBoxSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxSpeed.Location = new System.Drawing.Point(155, 59);
            this.TxBoxSpeed.Name = "TxBoxSpeed";
            this.TxBoxSpeed.ReadOnly = true;
            this.TxBoxSpeed.Size = new System.Drawing.Size(120, 14);
            this.TxBoxSpeed.TabIndex = 0;
            this.TxBoxSpeed.TabStop = false;
            this.TxBoxSpeed.Text = "Speed";
            this.TxBoxSpeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NumHitPoints
            // 
            this.NumHitPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumHitPoints.Location = new System.Drawing.Point(12, 32);
            this.NumHitPoints.Maximum = new decimal(new int[] {
            30000,
            0,
            0,
            0});
            this.NumHitPoints.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.NumHitPoints.Name = "NumHitPoints";
            this.NumHitPoints.Size = new System.Drawing.Size(120, 21);
            this.NumHitPoints.TabIndex = 1;
            this.NumHitPoints.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // TxBoxHitPoints
            // 
            this.TxBoxHitPoints.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxBoxHitPoints.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.TxBoxHitPoints.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxBoxHitPoints.Location = new System.Drawing.Point(12, 12);
            this.TxBoxHitPoints.Name = "TxBoxHitPoints";
            this.TxBoxHitPoints.ReadOnly = true;
            this.TxBoxHitPoints.Size = new System.Drawing.Size(120, 14);
            this.TxBoxHitPoints.TabIndex = 0;
            this.TxBoxHitPoints.TabStop = false;
            this.TxBoxHitPoints.Text = "Hit Points";
            this.TxBoxHitPoints.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BtAccept
            // 
            this.BtAccept.Location = new System.Drawing.Point(12, 136);
            this.BtAccept.Name = "BtAccept";
            this.BtAccept.Size = new System.Drawing.Size(120, 28);
            this.BtAccept.TabIndex = 5;
            this.BtAccept.Text = "Accept";
            this.BtAccept.UseVisualStyleBackColor = true;
            this.BtAccept.Click += new System.EventHandler(this.BtAccept_Click);
            // 
            // BtCancel
            // 
            this.BtCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtCancel.Location = new System.Drawing.Point(155, 136);
            this.BtCancel.Name = "BtCancel";
            this.BtCancel.Size = new System.Drawing.Size(120, 28);
            this.BtCancel.TabIndex = 6;
            this.BtCancel.Text = "Cancel";
            this.BtCancel.UseVisualStyleBackColor = true;
            // 
            // StatsEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.BtCancel;
            this.ClientSize = new System.Drawing.Size(287, 177);
            this.ControlBox = false;
            this.Controls.Add(this.BtCancel);
            this.Controls.Add(this.BtAccept);
            this.Controls.Add(this.NumHitPoints);
            this.Controls.Add(this.TxBoxHitPoints);
            this.Controls.Add(this.NumSpeed);
            this.Controls.Add(this.TxBoxSpeed);
            this.Controls.Add(this.NumDefence);
            this.Controls.Add(this.TxBoxDefence);
            this.Controls.Add(this.NumAttack);
            this.Controls.Add(this.TxBoxAttack);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "StatsEditor";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Stats";
            ((System.ComponentModel.ISupportInitialize)(this.NumAttack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumDefence)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NumHitPoints)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxBoxAttack;
        private System.Windows.Forms.NumericUpDown NumAttack;
        private System.Windows.Forms.NumericUpDown NumDefence;
        private System.Windows.Forms.TextBox TxBoxDefence;
        private System.Windows.Forms.NumericUpDown NumSpeed;
        private System.Windows.Forms.TextBox TxBoxSpeed;
        private System.Windows.Forms.NumericUpDown NumHitPoints;
        private System.Windows.Forms.TextBox TxBoxHitPoints;
        private System.Windows.Forms.Button BtAccept;
        private System.Windows.Forms.Button BtCancel;
    }
}